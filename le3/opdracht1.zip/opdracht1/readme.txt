Beste Harrie en Sylvia,

Hierbij mijn uitwerking van de eerste opdracht van Webapplicaties de clientkant.
Ik heb hiervoor gebruik gemaakt van cssgrid. Hiermee is het relatief makkelijk om de relatieve posities van de
onderdelen die ik wil gebruiken te laten bestaan. In grid-template-areas kun je makkelijk aangeven op welke posities
de onderdelen moeten staan. Ik heb ook gebruik gemaakt van een footer omdat je die ook op de meeste pagina's ziet.
